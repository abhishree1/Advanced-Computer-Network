How to execute code?

1. Please open Linux terminal
2. Command to compile code 
	g++ -o <Nameofexecuteablefile> <Filename.cpp>
3. Command to run the code
	./Nameofexecuteablefile

How to open file in terminal?
1. vi filename.cpp / filename.py
2. to exit without saving -> press esc, the type :q and enter.

Ex 1: For code having random function (Files: UDPPingerServer.py, TCPPingerServer.cpp) 
	
	UDPPingerServer.py
	1. Open terminal and type python3 UDPPingerServer.py to run the code


	UDPPingerClient.cpp
	1. Open other terminal and type 
		i. g++ -o UDPPingerClient UDPPingerClient.cpp
		ii. ./UDPPingerClient

		It will ask for no. of ping to execute, specify any no. and press enter.

Follow to same procedure of TCPPingerServer.cpp

You can follow the same steps to execute in different container. (Remember to change the ip address on client side).

Ex 2: For Running code with the help of netem function (Files: UDPPingerModifiedServer.py, TCPPingerModifiedServer.cpp)
	
	1. Open terminal and login into alice 1 (server) using below command, similarly open other terminal to login into bob1(client)
		 lxc exec alice1 -- /bin/bash
		
	2. To introduce 33% packet loss execute below command
		i. sudo tc qdisc add dev <device> root netem loss 33%
	
	To check if the 33% loss in set 
		sudo tc qdisc show dev <device>
	

	3. UDPPingerModifiedServer.cpp
		1. In alice1 terminal execute below command 
			i. g++ -o UDPPingerModifiedServer UDPPingerModifiedServer.cpp
			ii. ./UDPPingerModifiedServer
		UDPPingerClient.cpp
		1.  In bob1 terminal execute below command 
			i. g++ -o UDPPingerClient UDPPingerClient.cpp
			ii. ./UDPPingerClient

			It will ask for no. of ping to execute, specify any no. and press enter.

Follow the same procedure for TCPPingerModifiedServer.cpp

Ex 3: For concurent program (File: TCPPingerConcurrentServer.cpp)

1. Open terminal and login into alice 1 (server) using below command, similarly open other terminal to login into bob1(client) and trudy1(client)
		 lxc exec alice1 -- /bin/bash
		
	2. To introduce 33% packet loss execute below command
		i. sudo tc qdisc add dev <device> root netem loss 33%
	
	To check if the 33% loss in set 
		sudo tc qdisc show dev <device>
	

	3. TCPPingerConcurrentServer.cpp
		1. In alice1 terminal execute below command 
			i. g++ -o TCPPingerConcurrentServer TCPPingerConcurrentServer.cpp
			ii. ./TCPPingerConcurrentServer
		UDPPingerClient.cpp
		1.  In bob1 and trudy1 terminal execute below command 
			i. g++ -o TCPPingerClient TCPPingerClient.cpp
			ii. ./TCPPingerClient
	
			It will ask for no. of ping to execute, specify any no. and press enter.
