#include <arpa/inet.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>


using namespace std;

//Finding minimun element from array
int MinOfArray(int arr[],int size){

        int min=INT_MAX;
        for(int i=0;i<size;i++){
                if(arr[i]==-1){
                        continue;
                }
                else{
                        if( arr[i] < min){ min = arr[i]; }
                }
        }
        return min;
}
string convertToString(char* a)
{
    string s = a;
    return s;
}
//Finding max element from array
int MaxOfArray(int arr[],int size){

        int max=INT_MIN;
        for(int i=0;i<size;i++){
                if(arr[i]==-1){
                        continue;
                }
                else{
                        if(arr[i]>max){ max=arr[i]; }
                }
        }
        return max;


}

//Finding average of array
float AvgOfArray(int arr[],int size){

        int sum=0, n=size;
        for(int i=0;i<size;i++){
                if(arr[i]==-1){
                        n--;
                        continue;
                }
                else{
                     sum+=arr[i];
                }
        }
        return (float)sum/n;
}

//Calculation loss percentage
float LossCalcutaion(int arr[],float size){
        float n=0;
        for(int i=0;i<size;i++){
                if(arr[i] == -1){
                        n++;
                }
        }

        return (n/size)*100;
}
int main(int argc, char const *argv[])
{
    int cli_socket;
    char msg[15];
    char buffer[1024];
    //Creating Socket
    cli_socket = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    if(cli_socket<0){
        cout<<"Unable to create socket";
        exit(EXIT_FAILURE);
    }
    cout<<"Successfully created Socket!"<<endl;
    struct sockaddr_in server,client;

    memset(&server,0,sizeof(server));

    server.sin_family = AF_INET;
    server.sin_port= htons(8000);
    server.sin_addr.s_addr= inet_addr("172.31.0.2");

    //Setting Timeout timer
     struct timeval timeout;
     timeout.tv_sec = 1;
     timeout.tv_usec = 0;
     int ss;

     ss=setsockopt(cli_socket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
     if (ss<0) {
             cout << "Unable to set timeout timer"<< endl;
             exit(EXIT_FAILURE);
     }

    //Connection to server
    int status;
    status = connect(cli_socket, (struct sockaddr*)&server,sizeof(server));
    if(status<0){
        cout<<"Unable to connect to server";
        exit(EXIT_FAILURE);
    }

         cout<<"Connected to Server"<<endl;

         int req=0,response;

        //Taking input from terminal for how many number of times ping needs to run
        cout<<"Enter how many number of times you want to ping to server"<<endl;
        cin>>req;
        cout<<endl;
        int n;
        int time_rec[req];
        memset(time_rec,-1,sizeof(time_rec));

        for(int i=0;i<req;i++){

                time_t tn = time(NULL);
                //Sending message to server
                cout<<"Ping "<<i+1<<"  "<<ctime(&tn) <<endl;
                snprintf(msg,15,"ping %d",i+1);
                auto start = chrono::steady_clock::now();
                response=write(cli_socket, (const char *)msg, strlen(msg));
                if(response<0){
                        cout<<"Unable to send the message"<<endl;
                }
                else{

                        //Receiving message from server
                        n = recv(cli_socket, (char *)buffer, 1024,0);
                        auto end = chrono::steady_clock::now();
                        if(n<0){
                                if (errno == EWOULDBLOCK) {
                                        cout << "Request timed out" << endl;
                                        time_rec[i]=-1;
                               }
                                 else{
                                        cout<<"Unable to receive message"<<endl;
                                }
                         }
                        else{
                                buffer[n] = '\0';

                                //Converting string to upper case
                                char c_msg[sizeof(msg)];
                                 for(int i=0;i<sizeof(msg);i++){
                                        c_msg[i]=toupper(msg[i]);
                                 }

                                string s1 =convertToString(buffer);
                                string s2=convertToString(c_msg);


                                if(strcmp(buffer,c_msg)==0){
                                        cout<<"Client :"<<msg<<endl;
                                        cout<<"Server :"<<buffer<<endl;

                                        //Calculating RTT and storing it in array

                                        time_rec[i]=chrono::duration_cast<chrono::microseconds>(end - start).count();

                                        //Calculating Min, Max and Avg
                                        cout<<endl<<"Min :"<< MinOfArray(time_rec,i+1)<<" µs" << "  Max :" <<MaxOfArray(time_rec,i+1)<<" µs"  << "  Avg :"<<AvgOfArray(time_rec,i+1)<<" µs" <<endl;
                                        cout<<endl;
                                }

                                else
                                {
                                        if(s1.find(s2)!=string::npos){

                                        cout<<"Client :"<<msg<<endl;
                                        cout<<"Server :"<<buffer<<endl;
                                        for(int i= (sizeof(buffer)-sizeof(msg))+1 ;i<sizeof(buffer);i++){
                                                cout<<buffer[i];
                                        }

                                        cout<<endl;

                                        //Calculating RTT and storing it in array

                                        time_rec[i]=chrono::duration_cast<chrono::microseconds>(end - start).count();

                                        //Calculating Min, Max and Avg
                                        cout<<endl<<"Min :"<< MinOfArray(time_rec,i+1)<<" µs" << "  Max :" <<MaxOfArray(time_rec,i+1)<<" µs"  << "  Avg :"<<AvgOfArray(time_rec,i+1)<<" µs" <<endl;
                                        cout<<endl;

                                        }
                                else{
                                        while(strcmp(buffer,c_msg)!=0){
                                                n = recv(cli_socket, (char *)buffer, 1024,0);
                                        }

                                        cout<<"Client :"<<msg<<endl;
                                        cout<<"Server :"<<buffer<<endl;
                                        for(int i= sizeof(msg)+1 ;i<sizeof(buffer);i++){
                                                cout<<buffer[i];
                                        }

                                        cout<<endl;

                                        //Calculating RTT and storing it in array

                                        time_rec[i]=chrono::duration_cast<chrono::microseconds>(end - start).count();

                                        //Calculating Min, Max and Avg
                                        cout<<endl<<"Min :"<< MinOfArray(time_rec,i+1)<<" µs" << "  Max :" <<MaxOfArray(time_rec,i+1)<<" µs"  << "  Avg :"<<AvgOfArray(time_rec,i+1)<<" µs" <<endl;
                                        cout<<endl;



                                }
                        }


                        }
                                cout<<"****************************************************************************"<<endl<<endl;
                }
        sleep(5);
        }


        const char *e ="exit";
        send(cli_socket, (const char *)e, strlen(e),0);
        cout<<endl<<"Min :"<< MinOfArray(time_rec,req)<<" µs" <<endl;
        cout<< "Max :" <<MaxOfArray(time_rec,req)<<" µs" <<endl;
        cout<< "Total Avg :"<<AvgOfArray(time_rec,req)<<" µs" <<endl;
        cout<<"Loss Percentage :"<<LossCalcutaion(time_rec,req)<<"%"<<endl;
        cout<<endl;
        close(cli_socket);
        return 0;
}
