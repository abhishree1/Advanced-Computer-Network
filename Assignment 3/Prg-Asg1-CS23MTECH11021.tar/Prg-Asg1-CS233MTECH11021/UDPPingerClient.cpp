#include <arpa/inet.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>
#include <chrono>

using namespace std;

//Finding minimun element from array
int MinOfArray(int arr[],int size){

        int min=INT_MAX;
        for(int i=0;i<size;i++){
                if(arr[i]==-1){
                        continue;
                }
                else{
                        if( arr[i] < min){ min = arr[i]; }
                }
        }
        return min;
}

//Finding max element from array
int MaxOfArray(int arr[],int size){

        int max=INT_MIN;
        for(int i=0;i<size;i++){
                if(arr[i]==-1){
                        continue;
                }
                else{
                        if(arr[i]>max){ max=arr[i]; }
                }
        }
        return max;


}

//Finding average of array
float AvgOfArray(int arr[],int size){

        int sum=0, n=size;
        for(int i=0;i<size;i++){
                if(arr[i]==-1){
                        n--;
                        continue;
                }
                else{
                     sum+=arr[i];
                }
        }
        return (float)sum/n;
}

//Calculation loss percentage
float LossCalcutaion(int arr[],float size){
        float n=0;
        for(int i=0;i<size;i++){
                if(arr[i] == -1){
                        n++;
                }
        }

        return (n/size)*100;
}

int main() {
        int nw_socket;
        char buffer[1024];
        const char *msg = "hello there!";
        struct sockaddr_in server_addr;

        // Creating socket
        nw_socket = socket(AF_INET, SOCK_DGRAM, 0);
        if ( nw_socket < 0 ) {
                cout <<"socket creation failed";
                exit(EXIT_FAILURE);
        }

        memset(&server_addr, 0, sizeof(server_addr));

        //Setting Timeout timer
        struct timeval timeout;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;
        int ss;

        ss=setsockopt(nw_socket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
        if (ss<0) {
                cout << "Unable to set timeout timer"<< endl;
                exit(EXIT_FAILURE);
        }

        //Server Info
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(12000);
        server_addr.sin_addr.s_addr = INADDR_ANY;

        int req=0,response;

        //Taking input from terminal for how many number of times ping needs to run
        cout<<"Enter how many number of times you want to ping to server"<<endl;
        cin>>req;
        cout<<endl;
        int n;
        socklen_t len;
        int time_rec[req];
        memset(time_rec,-1,sizeof(time_rec));

        for(int i=0;i<req;i++){

                time_t tn = time(NULL);

                //Sending message to server
                cout<<"Ping "<<i+1<<"  "<<ctime(&tn) <<endl;

                auto start = chrono::steady_clock::now();
                response=sendto(nw_socket, (const char *)msg, strlen(msg),MSG_CONFIRM, (const struct sockaddr *) &server_addr,sizeof(server_addr));
                if(response<0){
                        cout<<"Unable to send the message"<<endl;
                }else{

                        //Receiving message from server
                        n = recvfrom(nw_socket, (char *)buffer, 1024,MSG_WAITALL, (struct sockaddr *) &server_addr,&len);
                        auto end = chrono::steady_clock::now();
                        if(n<0){
                                if (errno == EWOULDBLOCK) {
                                        cout << "Request timed out" << endl;
                                        time_rec[i]=-1;
                                }
                                else{
                                        cout<<"Unable to receive message"<<endl;
                                }
                        }
                        else{
                                buffer[n] = '\0';

                                cout<<"Client :"<<msg<<endl;
                                cout<<"Server :"<<buffer<<endl;

                                //Calculating RTT and storing it in array

                                time_rec[i]=chrono::duration_cast<chrono::microseconds>(end - start).count();

                                //Calculating Min, Max and Avg
                                cout<<endl<<"Min :"<< MinOfArray(time_rec,i+1)<<" µs" << "  Max :" <<MaxOfArray(time_rec,i+1)<<" µs"  << "  Avg :"<<AvgOfArray(time_rec,i+1)<<" µs" <<endl;
                                cout<<endl;
                        }
                                cout<<"****************************************************************************"<<endl<<endl;


                }
                sleep(5);
        }
        cout<<endl<<"Min :"<< MinOfArray(time_rec,req)<<" µs" <<endl;
        cout<< "Max :" <<MaxOfArray(time_rec,req)<<" µs" <<endl;
        cout<< "Total Avg :"<<AvgOfArray(time_rec,req)<<" µs" <<endl;
        cout<<"Loss Percentage :"<<LossCalcutaion(time_rec,req)<<"%"<<endl;
        cout<<endl;

        close(nw_socket);
        return 0;
}
