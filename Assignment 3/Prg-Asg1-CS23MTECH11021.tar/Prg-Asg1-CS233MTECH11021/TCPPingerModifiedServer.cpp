
#include <arpa/inet.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <ctime>

using namespace std;


int main(int argc, char const *argv[])
{
    int srv_socket;

    //Creating Socket
    srv_socket = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    if(srv_socket<0){
        cout<<"Unable to create socket";
        exit(EXIT_FAILURE);
    }
    cout<<"Successfully created Socket!"<<endl;
    struct sockaddr_in server,client;

    memset(&server,0,sizeof(server));

    server.sin_family = AF_INET;
    server.sin_port= htons(8000);
    server.sin_addr.s_addr= INADDR_ANY;

    //Binding Socket and port
    int status,ss;
    status = bind(srv_socket, (struct sockaddr*)&server,sizeof(server));
    if(status<0){
        cout<<"Unable to bind the socket";
        exit(EXIT_FAILURE);
    }
    cout<<"Binding Successfull !" <<endl<<"Server Listening !"<<endl;

    //Listening
    ss= listen(srv_socket,5);
    if(ss<0){
        cout<<"Unable to listen to any client";
        exit(EXIT_FAILURE);
    }

    int client_s,val=-1,res=-1;
    int l= sizeof(client);
    //Connecting to client

    client_s = accept(srv_socket, (struct sockaddr*)&client,(socklen_t*)&l);
    if(client_s<0){
        cout<<"Unable to listen to any client";
        exit(EXIT_FAILURE);
    }
        int count=1;
    char buffer[1024] = {0,};

    while(1){
        val=recv(client_s,buffer,1024,0);
        if(val<0){
            cout<<"Unable to receive message from client"<<endl;
                break;
        }
        else{
                //Checking exit condition
                if(strcmp(buffer,"exit")==0){break;}
                
                cout<<endl<<"Ping "<<count<<endl<<endl;

                cout<<"Message received form client : "<<buffer<<endl;

                //Converting string to upper case

                for(int i=0;i<sizeof(buffer);i++){
                        buffer[i]=toupper(buffer[i]);
                }

                res= send(client_s,buffer,sizeof(buffer),0);
                if(res<0){
                    cout<<"Unable to send message from client"<<endl;
                 }
                 else{
                        count++;
                         cout<<"Message sent to Client : "<<buffer<<endl;
                        memset(&buffer,0,sizeof(buffer));
                 }
        }
    }

    close(srv_socket);
    return 0;
}
