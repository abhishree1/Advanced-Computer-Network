#include <arpa/inet.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <ctime>

using namespace std;


int main(int argc, char const *argv[])
{
    int srv_socket;

    //Creating Socket
    srv_socket = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);
    if(srv_socket<0){
        cout<<"Unable to create socket";
        exit(EXIT_FAILURE);
    }
    cout<<"Successfully created Socket!"<<endl;
    struct sockaddr_in server,client;

    memset(&server,0,sizeof(server));
    memset(&server,0,sizeof(client));

    server.sin_family = AF_INET;
    server.sin_port= htons(12000);
    server.sin_addr.s_addr= INADDR_ANY;

    //Binding Socket and port
    int status,ss;
    status = bind(srv_socket, (struct sockaddr*)&server,sizeof(server));
    if(status<0){
        cout<<"Unable to bind the socket";
        exit(EXIT_FAILURE);
    }
    cout<<"Binding Successfull !" <<endl<<"Server Listening !"<<endl;


    int val,res;
    socklen_t l = sizeof(client);

    int count=1;
    char buffer[1024] = {0,};

    while(1){

        //receving message from client
        val=recvfrom(srv_socket,buffer,1024,0,(struct sockaddr*)&client,&l);
        if(val<0){
            cout<<"Unable to receive message from client"<<endl;
                break;
        }
        else{
                if(strcmp(buffer,"exit")==0){break;}
                cout<<endl<<"Ping "<<count<<endl<<endl;

                cout<<"Message received form client : "<<buffer<<endl;
                //Converting string to upper case

                for(int i=0;i<sizeof(buffer);i++){
                        buffer[i]=toupper(buffer[i]);
                }

                //sending message to client
                res= sendto(srv_socket,buffer,sizeof(buffer),0,(struct sockaddr*)&client, sizeof(struct sockaddr));
                if(res<0){
                    cout<<"Unable to send message from client"<<endl;
                 }
                 else{
                        count++;
                         cout<<"Message sent to Client : "<<buffer<<endl;
                        memset(&buffer,0,sizeof(buffer));
                 }
        }
    }

    close(srv_socket);
    return 0;
}
